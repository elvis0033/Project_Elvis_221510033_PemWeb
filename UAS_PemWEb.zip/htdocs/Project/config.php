<?php

$host = "sql302.infinityfree.com";
$user = "if0_39411730";
$pass = "Adududu17";
$db   = "if0_39411730_expense_tracker_schema";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>