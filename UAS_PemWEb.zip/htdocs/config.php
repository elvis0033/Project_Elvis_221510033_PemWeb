<?php
$host = "sql103.infinityfree.com";
$user = "if0_39413776";
$pass = "Adududu17";
$db   = "if0_39413776_expense_tracker_schema";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>